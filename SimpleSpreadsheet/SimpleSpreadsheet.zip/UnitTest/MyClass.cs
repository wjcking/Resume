﻿/*
 * Created by SharpDevelop.
 * User: lenovo
 * Date: 2018-10-19
 * Time: 16:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace UnitTest
{
	/// <summary>
	/// Description of MyClass.
	/// </summary>
	public class MyClass
	{
		
	}
}