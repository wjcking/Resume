﻿
using System;

namespace SimpleSpreadsheet
{
	/// <summary>
	/// The command class is used for inputing command lines and displaying.
	/// </summary>
	public static class Command
	{
		private static Spreadsheet spreadSheet;
		private const char DELIMITER_SPACE = ' ';
		static Command()
		{
			spreadSheet = new Spreadsheet();
		}
		public static string GetResult(string command)
		{
		 
			if (command.ToUpper() == "Q") {
				Environment.Exit(0);
				return "Exiting";
			}
				
			if (command.IndexOf(DELIMITER_SPACE) < 0 || command.Length < 3)
				return "Bad command or params\' name";
			 
		 
			string commandPrefix = command.Substring(0, 1).ToUpper();
			var splitedArray = command.Substring(2).Split(DELIMITER_SPACE.ToString().ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			string result = string.Empty;
 
			switch (commandPrefix)
			{
				case "C":
					((Spreadsheet)spreadSheet).Execute(splitedArray);
					result = ((Spreadsheet)spreadSheet) .ToString();
					break;
				case "S":
					spreadSheet = new Sum();
					((Sum)spreadSheet).Execute(splitedArray);
					result = ((Sum)spreadSheet).ToString();
					break;
				case "N":
					spreadSheet = new Insert();
					((Insert)spreadSheet).Execute(splitedArray);
					result = ((Insert)spreadSheet).ToString();
					break;			
			}

			return result;
		}
		public static void Clear()
		{
			if (null != spreadSheet)
				spreadSheet.Clear();
		}
	}
}
