﻿/*
 * Created by Jacky.
 */
using System;

namespace SimpleSpreadsheet
{
	/// <summary>
	/// Description of Sum.
	/// </summary>
	public class Sum : Spreadsheet
	{
		public Sum()
		{
			 
		}
		public override void Execute(string[] splited)
		{
			int sum = 0;
			ProcessArray((value) => {
		 
			});
		}
		
		public override string ToString()
		{
			return base.ToString();
		}
	}
}
