﻿
using System;
using System.Collections.Generic;
using System.Text;
namespace SimpleSpreadsheet
{
	/// <summary>
	/// Basic settings of Spreadsheet.
	/// </summary>
	public class Spreadsheet
	{
		protected const char DELIMITER_CONNECT = '-';
		protected const char DELIMITER_SLICE = '|';
 
		protected static int width = 20;
		protected static int height = 4;
		/// <summary>
		/// Attention: height(y) is first parameter, width(x) is the second one.
		/// </summary>
		protected static int[,] vectors = new int[4,20];
	//	protected string[] splited;
		protected static StringBuilder tableBuilder = new StringBuilder();
	 		
	
		public Spreadsheet()
		{
			
		}	
		/// <summary>
		/// has to be a property or function, cause need a refresh after changing width or height.
		/// </summary>
		private static int WidthOffset
		{ 
			get { return width * 3 - 1;}
		}
		/// <summary>
		/// Print the top or bottom of the number table
		/// </summary>
		protected void RenderLine()
		{ 
			tableBuilder.AppendLine(string.Empty.PadRight(WidthOffset, DELIMITER_CONNECT));
		}

		protected void RenderValues()
		{
			ProcessArray((value) => {
				 var output = DELIMITER_SLICE.ToString().PadRight(3) + value.ToString().PadRight(3);
				 tableBuilder.AppendLine(output.PadRight(WidthOffset) + DELIMITER_SLICE);
			});
		}
		public virtual void Execute(string[] splited)
		{
			int.TryParse(splited[0], out width);
			int.TryParse(splited[1], out height);
			vectors = new int[height, width];
			RenderLine();
			for (int i = 0; i < height; i++) 
			{
				tableBuilder.Append(DELIMITER_SLICE.ToString().PadRight(WidthOffset));
				tableBuilder.AppendLine(DELIMITER_SLICE.ToString());
			}
		}
		/// <summary>
		/// Used a function pointer for saving coding iteration or a sum up
		/// </summary>
		/// <param name="func">(x)=>{}</param>
		/// <param name="startX">default or customize</param>
		/// <param name="startY">default or customize</param>
		/// <param name="endX">default or customize</param>
		/// <param name="endY">default or customize</param>
		protected void ProcessArray(Action<int> func, int startX = 0, int startY = 0, int endX = 0, int endY = 0)
		{
			endX = endX == 0 ? width  : endX;
			endY = endY == 0 ? height  : endY;
			for (int y = startY; y < endY ; y++)
				for (int x = startX; x < endX; x++)
					if (vectors[y,x] != 0)
						func(vectors[y, x]);
		}
		public override string ToString()
		{
			RenderLine();
			return tableBuilder.ToString();
		}
		/// <summary>
		/// clear the content of table builder so that it could be displayed from beginnings
		/// </summary>
		public void Clear()
		{
			tableBuilder.Clear();
		}
	}
}
