﻿/*
 * Created by Jacky.wu.
 */
using System;
using System.Collections.Generic;

namespace SimpleSpreadsheet
{
	/// <summary>
	/// Description of Insert.
	/// </summary>
	public class Insert:Spreadsheet
	{
		public Insert()
		{
 
	 
		}
		public override void Execute(string[] splited)
		{ 
			int x = 0;
			int y = 0;
			int v = 0;
		 
			if (splited.Length < 3)
				throw new Exception(splited.ToString() + " should be 3 params like: N x y v ");
			 
			int.TryParse(splited[0].Substring(0), out x);
		 
			int.TryParse(splited[1].Substring(0), out y);
	 
			if (!int.TryParse(splited[2].Substring(0), out v))
				throw new Exception("v is not a number");
		 
			//the offset of subscript 
			if (x < 0 || x >= width)
				throw new Exception("x out of boundary");
			if (y < 0 || y >= height)
				throw new Exception("y out of boundary");

			vectors[x - 1, y - 1] = v;
			//RenderLine();
		}
		public override string ToString()
		{
			RenderLine();
			RenderValues();
			return base.ToString();
		}
	}
}
