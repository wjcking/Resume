﻿
Attached is the Coding Test for the position.

 

Tips for the coding “Task – Simple Spreadsheet”:

“The task should follow the guidelines:

Application should be developed as requested and the following things should be present:
Spreadsheet UI. Spreadsheet state should be printed after every operation
Unit Tests. Coverage of main business logic. All passing
Documentation. Clear and well-structured description of how to run app and tests and any other information
Git commits. App development is expected to be done in multiple commits with proper description and etc.
Architecture and coding style
Do not break SOLID principles. Separate concerns: business logic and presentation at least. App runner UI and Spreadsheet logic.
Use proper and professional approach to naming projects, classes, variables.
Do not over-design. But don’t make everything become one single god class
Follow requirements
Application should function as requested + all features should be tested. ~70% test coverage
All incorrect input should be handled and error message produced”
 

 

Below is a brief Introduction of EPAM:

Established in 1993, EPAM, a leading global product development and digital engineering services company, started in Belarus and the U.S. and listed on the NYSE (NYSE:EPAM), employs over 25,000 IT professionals and delivers innovative solutions to its clients in more than 25 countries across North America, Europe, Asia and Australia by utilizing its award-winning global delivery platform.

 

请注意coding的结构+ Unit Test

 

You could reach me via Wechat account: Leoliangsz

Or Skype Account: leo_liang@epam.com

 

 

Best Regards,

 

 

 

Leo Liang

Lead Recruiter

 

Office: +86 755 3689 9008 - 63836   Email: leo_liang@epam.com

Shenzhen, China   epam.com

 

CONFIDENTIALITY CAUTION AND DISCLAIMER
This message is intended only for the use of the individual(s) or entity(ies) to which it is addressed and contains information that is legally privileged and confidential. If you are not the intended recipient, or the person responsible for delivering the message to the intended recipient, you are hereby notified that any dissemination, distribution or copying of this communication is strictly prohibited. All unintended recipients are obliged to delete this message and destroy any printed copies.