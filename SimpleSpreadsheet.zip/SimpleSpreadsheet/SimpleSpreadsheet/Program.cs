﻿
using System;

namespace SimpleSpreadsheet
{
	class Program
	{
		public static void Main(string[] args)
		{
			while (true) {
				Console.Write("enter command:");
				try {
					var result = Translator.Translate(Console.ReadLine());
					Console.WriteLine(result);
				//	Command.Clear();
				} catch (Exception e) {
					Console.WriteLine(e.Message);
				}
				System.Threading.Thread.Sleep(222);
			}
		}
	}
}