﻿/*
 * Created by Jacky.wu.
 */
using System;
using System.Collections.Generic;

namespace SimpleSpreadsheet
{
	/// <summary>
	///  Insert a new.
	/// </summary>
	public class Insert:Spreadsheet
	{
		public Insert()
		{
 
	 
		}
		public new void Interpret(string[] splited)
		{ 
			int x = 0;
			int y = 0;
			int v = 0;
		 
			if (splited.Length < 3)
				throw new Exception(splited.ToString() + " should be 3 params like: N x y v ");
			 
			int.TryParse(splited[0], out x);		 
			int.TryParse(splited[1], out y);
	 
			if (!int.TryParse(splited[2], out v))
				throw new Exception("v is not a number");
		 
			//the offset of subscript 
			if (x < 0 || x >= width)
				throw new Exception("x out of boundary");
			if (y < 0 || y >= height)
				throw new Exception("y out of boundary");

			vectors[y - 1, x - 1] = v;
			//RenderLine();
		}
		public override string ToString()
		{
			RenderLine();
			RenderValues();
			return base.ToString();
		}
	}
}
