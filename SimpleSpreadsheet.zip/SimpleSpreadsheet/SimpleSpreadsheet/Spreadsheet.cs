﻿using System;
using System.Collections.Generic;
using System.Text;
namespace SimpleSpreadsheet
{
	/// <summary>
	/// Basic settings of Spreadsheet.
	/// </summary>
	public class Spreadsheet
	{
		protected const char DELIMITER_CONNECT = '-';
		protected const char DELIMITER_SLICE = '|';
 
		protected static int width = 20;
		protected static int height = 4;
		/// <summary>
		/// Attention: height(y) is first parameter, width(x) is the second one.
		/// </summary>
		protected static int[,] vectors = new int[4,20];
	//	protected string[] splited;
		protected static StringBuilder tableBuilder = new StringBuilder();
	 		
	
		public Spreadsheet()
		{
			
		}	
		/// <summary>
		/// has to be a property or function, cause need a refresh after changing width or height.
		/// </summary>
		private static int WidthOffset
		{ 
			get { return width * 3 + 3 ;}
		}
		/// <summary>
		/// Used  function pointers for  iteration print or a sum up
		/// </summary>
		/// <param name="each">(x)=>{}</param> 
		/// <param name="startX">default or customize</param>
		/// <param name="startY">default or customize</param>
		/// <param name="endX">default or customize</param>
		/// <param name="endY">default or customize</param>
		protected void ProcessVector(Action<int,int,bool> each = null, 
		                             int startX = 0, int startY = 0, int endX = -1, int endY = -1)
		{
			
			//traverse all of vectors
			endX = endX < 0 ? width -1  : endX;
			endY = endY < 0 ? height -1 : endY;
			// for sum up
			// if end subscripts are 0 then set to 1 in order to proceed iteration
			// otherwise
			endX = endX == 0 ? ++endX : endX;
			endY = endY == 0 ? ++endY : endY;
			

			//attetion y first , x second, if sum up ,must include start and end element 
			//that is why <= used. not <
			for (int y = startY; y <= endY ; y++)
			{
				for (int x = startX; x <= endX; x++)
						each(y,vectors[y, x],x == endX);
			}
		}
		
		/// <summary>
		/// Print the top or bottom of the number table
		/// </summary>
		protected void RenderLine()
		{ 
			tableBuilder.AppendLine(string.Empty.PadRight(WidthOffset, DELIMITER_CONNECT));
		}

		protected void RenderValues()
		{
			int currentRow = -1;
			string output = string.Empty;
			ProcessVector(
				(row,value,isRowEnd) =>
				{
					if (currentRow != row)
					{
					  output = DELIMITER_SLICE.ToString().PadRight(3);
						tableBuilder.Append(output);
					  currentRow = row;
					}
					//if (value != 0)
					//{
					tableBuilder.Append(value == 0 ? string.Empty.PadRight(3): value.ToString().PadRight(3));
						if (isRowEnd)
							tableBuilder.AppendLine(DELIMITER_SLICE.ToString());
					//}
				}
			);
		}
		public virtual void Interpret(string[] splited)
		{
			int.TryParse(splited[0], out width);
			int.TryParse(splited[1], out height);
			// assgin a new for Creating
			vectors = new int[height, width];
			RenderLine();
			// empty values
			for (int i = 0; i < height; i++) 
			{
				tableBuilder.Append(DELIMITER_SLICE.ToString().PadRight(WidthOffset));
				tableBuilder.AppendLine(DELIMITER_SLICE.ToString());
			}
		}
		
		public override string ToString()
		{
			RenderLine();
			return tableBuilder.ToString();
		}
		/// <summary>
		/// clear the content of table builder so that it could be displayed from beginnings
		/// </summary>
		public void Clear()
		{
			tableBuilder.Clear();
		}
	}
}
