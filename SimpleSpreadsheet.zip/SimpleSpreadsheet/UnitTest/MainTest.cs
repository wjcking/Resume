﻿/*
 * Created by Jacky.
 * Main
 */
using System;
using NUnit.Framework;
using SimpleSpreadsheet;
namespace UnitTest
{
	[TestFixture]
	public class MainTest
	{
		[Test]
		public void Test1()
		{ 
			Console.WriteLine();
			var result = string.Empty;
			result = Translator.Translate("C 20 4");
			Console.WriteLine(result);
			result = Translator.Translate("N 1 2 2");
			Console.WriteLine(result);
			result = Translator.Translate("N 1 3 4");
			Console.WriteLine(result);
			result = Translator.Translate("S 1 2 1 3 1 4");
			Console.WriteLine(result);
		}
		 
		[Test]
		public void Test2()
		{ 
			Console.WriteLine();
			var result = string.Empty;
			result = Translator.Translate("C 12 6");
			Console.WriteLine(result);
			result = Translator.Translate("N 1 1 1");
			Console.WriteLine(result);
			result = Translator.Translate("N 1 2 2");
					Console.WriteLine(result);
			result = Translator.Translate("N 1 3 3");
			Console.WriteLine(result);
			result = Translator.Translate("S 1 1 1 3 1 4");
			Console.WriteLine(result);
		}
		
		[Test]
		public void Test3()
		{ 
			Test1();
			Test2();
		}
		
		[Test]
		public void TestMutilpleRows()
		{ 
			var result = Translator.Translate("C 5 4");
			Console.WriteLine(result);
			result = Translator.Translate("N 1 1 1");
			Console.WriteLine(result);
			result = Translator.Translate("N 1 2 2");
			Console.WriteLine(result);
			
			Console.WriteLine(result);
			result = Translator.Translate("N 2 1 21");
			Console.WriteLine(result);
			result = Translator.Translate("N 2 2 22");
			Console.WriteLine(result);
			
			result = Translator.Translate("S 2 1 2 2 1 4");
			Console.WriteLine(result);
		}
	}
}
